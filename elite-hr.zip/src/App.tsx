import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { HomeDashboard } from './components/HomeDashboard';
import { DiscoveryBoard } from './components/DiscoveryBoard';
import { InboxBoard } from './components/InboxBoard';
import { ReferralsBoard } from './components/ReferralsBoard';
import { AnalyticsBoard } from './components/AnalyticsBoard';
import { SettingsBoard } from './components/SettingsBoard';

import { ActiveTab, UserProfile, EmailThread, ReferralCandidate, EmailTemplate } from './types';
import { 
  PROFILES, 
  HOME_KPI_CARDS, 
  TIMELINE_ITEMS, 
  SAVED_JOBS, 
  FOLLOW_UP_REMINDERS, 
  TRENDING_OPPORTUNITIES, 
  DISCOVERY_JOBS, 
  EMAIL_THREADS, 
  REFERRAL_STATUSES, 
  TOP_REFERRERS, 
  EMAIL_TEMPLATES 
} from './data';

export default function App() {
  // Global View Navigation State
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Sourcing Profiles Database
  const [profiles, setProfiles] = useState<UserProfile[]>(PROFILES);
  const [currentProfile, setCurrentProfile] = useState<UserProfile>(PROFILES[0]); // Alexander Thorne

  // Core Data Collections
  const [kpiCards, setKpiCards] = useState(HOME_KPI_CARDS);
  const [timelineItems, setTimelineItems] = useState(TIMELINE_ITEMS);
  const [savedJobs, setSavedJobs] = useState(SAVED_JOBS);
  const [reminders, setReminders] = useState(FOLLOW_UP_REMINDERS);
  const [trendingOpportunities, setTrendingOpportunities] = useState(TRENDING_OPPORTUNITIES);
  const [discoveryJobs, setDiscoveryJobs] = useState(DISCOVERY_JOBS);
  const [emailThreads, setEmailThreads] = useState<EmailThread[]>(EMAIL_THREADS);
  const [referrals, setReferrals] = useState<ReferralCandidate[]>(REFERRAL_STATUSES);
  const [topReferrers, setTopReferrers] = useState(TOP_REFERRERS);
  const [templates, setTemplates] = useState<EmailTemplate[]>(EMAIL_TEMPLATES);

  // Interaction: Toggle Favorites inside Trending opportunities
  const handleToggleFavoriteTrend = (id: string) => {
    setTrendingOpportunities(prev => 
      prev.map(item => item.id === id ? { ...item, isFavorite: !item.isFavorite } : item)
    );
  };

  // Interaction: Toggle Bookmark within Discovery opportunities
  const handleToggleFavoriteJob = (id: string) => {
    setDiscoveryJobs(prev => 
      prev.map(item => item.id === id ? { ...item, isFavorite: !item.isFavorite } : item)
    );
  };

  // Interaction: Advance Kanban Referrals Pipeline stages
  const handleUpdateReferralStage = (
    id: string, 
    newStage: 'referred' | 'screening' | 'interviewing' | 'hired'
  ) => {
    const stageStatusTextMap: Record<string, string> = {
      referred: 'Direct Referral',
      screening: 'HR Call Scheduled',
      interviewing: 'Final Round Interview',
      hired: `Closed - ${new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`
    };

    setReferrals(prev => 
      prev.map(cand => 
        cand.id === id 
          ? { ...cand, stage: newStage, statusText: stageStatusTextMap[newStage] } 
          : cand
      )
    );

    // If candidate gets status Hired, dynamically increment some metric for gamification
    if (newStage === 'hired') {
      setTimelineItems(prev => [
        {
          id: `timeline-hired-${Date.now()}`,
          title: 'Referral Pipeline Placed!',
          description: `A referred candidate has been elevated to Hired status. Commission approved.`,
          time: 'Just now',
          type: 'offer',
          isHighPriority: true
        },
        ...prev
      ]);
    }
  };

  // Interaction: Inject dynamic candidate submission into the Kanban list
  const handleAddReferral = (
    candidateName: string, 
    role: string, 
    department: string, 
    source: string
  ) => {
    const newRef: ReferralCandidate = {
      id: `ref-dynamic-${Date.now()}`,
      name: candidateName,
      role: role,
      department: department as any,
      stage: 'referred',
      source: source as any,
      statusText: 'Direct Referral'
    };

    setReferrals(prev => [newRef, ...prev]);

    // Push timeline record
    setTimelineItems(prev => [
      {
        id: `timeline-add-${Date.now()}`,
        title: 'New Candidate Submitted',
        description: `Successfully referred ${candidateName} for the ${role} position.`,
        time: 'Just now',
        type: 'referral'
      },
      ...prev
    ]);

    // Keep KPI cards matching
    setKpiCards(prev => 
      prev.map(k => k.title === 'Referrals Made' ? { ...k, value: String(parseInt(k.value) + 1) } : k)
    );
  };

  // Interaction: Send E-mail reply within thread composer
  const handleSendReply = (threadId: string, replyBody: string) => {
    setEmailThreads(prev => 
      prev.map(th => {
        if (th.id === threadId) {
          return {
            ...th,
            status: 'Sent',
            time: 'Just now',
            tags: ['Sent', 'Awaiting Action'],
            conversation: [
              ...th.conversation,
              {
                senderName: currentProfile.name,
                senderEmail: currentProfile.email,
                avatarUrl: currentProfile.avatar,
                time: 'Just now',
                body: replyBody,
                isUser: true
              }
            ]
          };
        }
        return th;
      })
    );

    // Inject timeline event
    setTimelineItems(prev => [
      {
        id: `timeline-email-${Date.now()}`,
        title: 'Recruited Correspondence Sent',
        description: `Sent strategic follow-up email response. Tone tailored via workspace assistant.`,
        time: 'Just now',
        type: 'update'
      },
      ...prev
    ]);

    // Increment KPIs
    setKpiCards(prev => 
      prev.map(k => k.title === 'Emails Sent' ? { ...k, value: String(parseInt(k.value.replace(/,/g, '')) + 1) } : k)
    );
  };

  // Settings: Save overall profile metadata
  const handleUpdateProfile = (updatedProfile: UserProfile) => {
    setCurrentProfile(updatedProfile);
    // Sync current profiles matrix
    setProfiles(prev => prev.map(p => p.email === updatedProfile.email ? updatedProfile : p));
  };

  // Settings: Edit global outreach templates
  const handleUpdateTemplate = (templateId: string, updatedFields: Partial<EmailTemplate>) => {
    setTemplates(prev => 
      prev.map(tpl => tpl.id === templateId ? { ...tpl, ...updatedFields } : tpl)
    );
  };

  // Global counts for badge indicators
  const unreadInboxCount = emailThreads.filter(t => t.status === 'Opened').length;

  // Render proper sub views
  const renderActiveView = () => {
    switch (activeTab) {
      case 'home':
        return (
          <HomeDashboard
            currentProfile={currentProfile}
            kpis={kpiCards}
            timeline={timelineItems}
            savedJobs={savedJobs}
            reminders={reminders}
            trending={trendingOpportunities}
            onToggleFavoriteTrend={handleToggleFavoriteTrend}
            onNavigateToTab={(tab) => {
              setActiveTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onReferCandidate={(title, company) => {
              // Quick transfer to discovery and open target refer modal if preferred,
              // or navigate to referrals board instantly
              setActiveTab('referrals');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            searchQuery={searchQuery}
          />
        );
      case 'discovery':
        return (
          <DiscoveryBoard
            jobs={discoveryJobs}
            onToggleFavoriteJob={handleToggleFavoriteJob}
            onAddReferral={handleAddReferral}
            searchQuery={searchQuery}
          />
        );
      case 'inbox':
        return (
          <InboxBoard
            threads={emailThreads}
            currentProfile={currentProfile}
            onSendReply={handleSendReply}
            searchQuery={searchQuery}
          />
        );
      case 'referrals':
        return (
          <ReferralsBoard
            referrals={referrals}
            topReferrers={topReferrers}
            onUpdateStage={handleUpdateReferralStage}
            onAddReferral={handleAddReferral}
          />
        );
      case 'analytics':
        return <AnalyticsBoard />;
      case 'settings':
        return (
          <SettingsBoard
            currentProfile={currentProfile}
            profiles={profiles}
            onUpdateProfile={handleUpdateProfile}
            templates={templates}
            onUpdateTemplate={handleUpdateTemplate}
          />
        );
      default:
        return (
          <div className="p-8 bg-white border border-[#ecebe6] rounded-xl text-center text-xs text-neutral-400 font-light">
            View nodes under maintenance. Select a different tab inside the left rail menu.
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#faf9f6] flex text-neutral-800">
      
      {/* Sidebar Command Station */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentProfile={currentProfile}
        profiles={profiles}
        onProfileChange={(newProf) => {
          setCurrentProfile(newProf);
          // Set specific tabs aligned to their image context if helpful
          if (newProf.name === 'Alex Mercer') {
            setActiveTab('inbox');
          } else if (newProf.name === 'Alex Sterling') {
            setActiveTab('referrals');
          } else if (newProf.name === 'Arthur Sterling') {
            setActiveTab('analytics');
          } else {
            setActiveTab('home');
          }
        }}
        unreadCount={unreadInboxCount}
      />

      {/* Main Core Frame Layout Column */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Universal Top Header */}
        <Header
          currentProfile={currentProfile}
          activeTab={activeTab}
          onSearch={(val) => setSearchQuery(val)}
        />

        {/* Dynamic Responsive Screen Portals Pane */}
        <main className="flex-1 overflow-y-auto px-8 py-8 max-w-7xl w-full mx-auto space-y-4">
          {renderActiveView()}
        </main>
      </div>
    </div>
  );
}
